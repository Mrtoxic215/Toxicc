#include "BinderHook.h"
#include <BoxCore.h>
#include "JniHook/JniHook.h"

HOOK_JNI(jint, getCallingUid, JNIEnv *env, jobject obj) {

    if (!env) {
        return orig_getCallingUid(env, obj);
    }

    int orig = orig_getCallingUid(env, obj);
    return BoxCore::getCallingUid(env, orig);
}


void BinderHook::init(JNIEnv *env) {
    const char *clazz = "android/os/Binder";
    JniHook::HookJniFun(env, clazz, "getCallingUid", "()I", (void *) new_getCallingUid,(void **) (&orig_getCallingUid), true);
}