package android.MetaCore

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import java.lang.reflect.Field
import org.lsposed.lsparanoid.Obfuscate

@Obfuscate
object AdvancedPopupHelper {

    private val handler = Handler(Looper.getMainLooper())

    private fun getTopActivity(): Activity? {
        return try {
            val atClass = Class.forName("android.app.ActivityThread")
            val currentAT = atClass.getMethod("currentActivityThread").invoke(null)
            val mActivitiesField: Field = atClass.getDeclaredField("mActivities")
            mActivitiesField.isAccessible = true
            val activities = mActivitiesField.get(currentAT) as Map<*, *>

            for (record in activities.values) {
                val rClass = record!!::class.java
                val pausedField = rClass.getDeclaredField("paused")
                pausedField.isAccessible = true
                if (!pausedField.getBoolean(record)) {
                    val activityField = rClass.getDeclaredField("activity")
                    activityField.isAccessible = true
                    return activityField.get(record) as Activity
                }
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    @JvmStatic
    fun showAuto() {
        val act = getTopActivity() ?: return
        if (act.isFinishing || act.isDestroyed) return
        showPopup(act)
    }

    private fun showPopup(act: Activity) {
        handler.post {
            try {
                val dialog = Dialog(act, android.R.style.Theme_Translucent_NoTitleBar)
                dialog.setCancelable(false)

                val webView = WebView(act)
                webView.settings.javaScriptEnabled = true
                webView.settings.domStorageEnabled = true
                webView.setBackgroundColor(Color.TRANSPARENT)
                webView.webViewClient = WebViewClient()

                val deviceInfo = """
                    Device: ${Build.MANUFACTURER} ${Build.MODEL}
                    Android: ${Build.VERSION.RELEASE}
                    SDK: ${Build.VERSION.SDK_INT}
                """.trimIndent()

                webView.addJavascriptInterface(object {
                    @JavascriptInterface
                    fun close() {
                        handler.post {
                            if (dialog.isShowing) dialog.dismiss()
                        }
                    }

                    @JavascriptInterface
                    fun getDeviceInfo(): String = deviceInfo
                }, "Android")

                webView.loadDataWithBaseURL(null, HTML, "text/html", "utf-8", null)
                dialog.setContentView(webView)
                dialog.show()

                dialog.window?.apply {
                    // Super compact size
                    setLayout(dp(act, 240), dp(act, 360))
                    setGravity(Gravity.CENTER)
                    addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                    setDimAmount(0.85f)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        attributes?.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    }
                }
            } catch (_: Throwable) { }
        }
    }

    private fun dp(act: Activity, v: Int): Int = (v * act.resources.displayMetrics.density).toInt()

    private val HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, initial-scale=1, maximum-scale=1">
<title>RIYAZ License</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.12.2/lottie.min.js"></script>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body {
    background: transparent;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    font-family: 'Inter', system-ui, sans-serif;
    overflow: hidden;
}
/* SUPER COMPACT PREMIUM CARD */
.card {
    width: 240px;
    background: rgba(6, 6, 12, 0.88);
    backdrop-filter: blur(20px);
    border-radius: 32px;
    padding: 14px 12px 16px;
    position: relative;
    overflow: visible;
    box-shadow: 0 20px 35px -8px rgba(0,0,0,0.8), 0 0 0 1.5px rgba(255,200,80,0.4) inset;
    animation: cardReveal 0.55s cubic-bezier(0.21, 1.11, 0.35, 1.05);
    transition: transform 0.2s ease;
}
.card:hover {
    transform: scale(1.01);
}
/* Animated rainbow gold border */
.card::before {
    content: '';
    position: absolute;
    inset: -2px;
    border-radius: 34px;
    background: linear-gradient(135deg, #FFD966, #FF9F4A, #FF5E7E, #FFD966);
    opacity: 0;
    z-index: -1;
    animation: borderFlow 4s linear infinite alternate;
    filter: blur(8px);
}
.card::after {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: 32px;
    background: radial-gradient(circle at 30% 20%, rgba(255,215,0,0.12), transparent 80%);
    pointer-events: none;
}
@keyframes cardReveal {
    0% { opacity: 0; transform: scale(0.85) translateY(25px); filter: blur(8px); }
    100% { opacity: 1; transform: scale(1) translateY(0); filter: blur(0); }
}
@keyframes borderFlow {
    0% { opacity: 0.3; filter: blur(5px); }
    50% { opacity: 0.7; filter: blur(7px); }
    100% { opacity: 0.4; filter: blur(6px); background: linear-gradient(135deg, #FFB347, #FF6B6B, #4DF8FF, #FFB347); }
}
/* Floating particles - more of them, smoother */
.particle {
    position: absolute;
    background: radial-gradient(circle, rgba(255,215,0,0.7), rgba(255,100,100,0.3));
    border-radius: 50%;
    pointer-events: none;
    animation: floatPremium 6s infinite cubic-bezier(0.45, 0, 0.55, 1);
    z-index: -1;
}
@keyframes floatPremium {
    0% { transform: translateY(0) translateX(0) scale(1); opacity: 0; }
    20% { opacity: 0.6; }
    80% { opacity: 0.4; }
    100% { transform: translateY(-70px) translateX(35px) scale(0); opacity: 0; }
}
/* Header */
.header {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-bottom: 10px;
    padding-bottom: 8px;
    border-bottom: 1px solid rgba(255,215,0,0.5);
}
.title-icon {
    width: 26px;
    height: 26px;
    filter: drop-shadow(0 0 6px #FFD966);
}
.title {
    font-size: 15px;
    font-weight: 800;
    background: linear-gradient(135deg, #FFE6B3, #FFB347);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    letter-spacing: 0.3px;
}
/* Expire badge */
.expire-status {
    background: linear-gradient(145deg, rgba(255,70,70,0.2), rgba(255,180,40,0.12));
    border-radius: 40px;
    padding: 5px 10px;
    margin: 8px 0;
    text-align: center;
    border: 0.5px solid rgba(255,215,0,0.6);
    backdrop-filter: blur(4px);
}
.expire-text {
    font-size: 9px;
    font-weight: 700;
    color: #FFDFA5;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
}
/* Device info - compact */
.device-info {
    background: rgba(20, 20, 35, 0.7);
    backdrop-filter: blur(8px);
    border-radius: 20px;
    padding: 6px 10px;
    margin: 8px 0;
    border: 0.5px solid rgba(255,215,0,0.35);
}
.info-row {
    display: flex;
    justify-content: space-between;
    margin: 3px 0;
    font-size: 8.5px;
}
.info-label {
    color: #B0B0D8;
    font-weight: 500;
}
.info-value {
    color: #FFE0A5;
    font-weight: 700;
    font-family: monospace;
}
/* Content rows */
.content {
    margin: 8px 0 6px;
}
.row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 5px 0;
    padding: 4px 8px;
    background: rgba(255,215,0,0.05);
    border-radius: 32px;
    border: 0.5px solid rgba(255,215,0,0.2);
    transition: all 0.2s;
}
.row:active {
    transform: scale(0.98);
    background: rgba(255,215,0,0.1);
}
.icon {
    width: 18px;
    height: 18px;
    flex-shrink: 0;
}
.text {
    font-size: 9px;
    font-weight: 600;
    color: #F2F2FF;
}
.highlight {
    color: #FFD966;
    font-weight: 800;
    margin-right: 3px;
}
/* Android support */
.android-support {
    text-align: center;
    margin: 8px 0;
    padding: 3px 8px;
    background: linear-gradient(90deg, rgba(0,212,255,0.12), rgba(255,215,0,0.06));
    border-radius: 30px;
    border: 0.5px solid rgba(255,215,0,0.35);
}
.support-text {
    font-size: 8px;
    font-weight: 700;
    color: #7FDBFF;
}
/* Footer */
.footer {
    margin-top: 8px;
    text-align: center;
    padding-top: 6px;
    border-top: 0.5px solid rgba(255,215,0,0.4);
}
.footer-row {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    margin-bottom: 3px;
}
.footer-icon {
    width: 16px;
    height: 16px;
}
.footer-text {
    font-size: 9px;
    font-weight: 800;
    background: linear-gradient(145deg, #FFD966, #FFA559);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
}
.footer-note {
    font-size: 7px;
    color: #AACCFF;
    margin-bottom: 5px;
}
/* Countdown ring */
.countdown-card {
    background: rgba(0, 0, 0, 0.55);
    border-radius: 34px;
    padding: 6px 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    backdrop-filter: blur(8px);
    border: 0.5px solid rgba(255,215,0,0.5);
    margin-bottom: 8px;
}
.timer-label {
    font-size: 8px;
    font-weight: 700;
    color: #DDDDFF;
}
.timer-digits {
    font-size: 20px;
    font-weight: 800;
    font-family: monospace;
    background: linear-gradient(135deg, #FFE6B3, #FFB347);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
    line-height: 1;
}
.ring-container {
    width: 30px;
    height: 30px;
}
.circular-ring {
    transform: rotate(-90deg);
    width: 30px;
    height: 30px;
}
.bg-ring {
    stroke: rgba(255,255,255,0.2);
    stroke-width: 2;
    fill: none;
}
.progress-ring {
    stroke: url(#goldGrad);
    stroke-width: 2;
    stroke-linecap: round;
    fill: none;
    transition: stroke-dasharray 0.1s linear;
}
/* Close button */
.close-button {
    background: linear-gradient(95deg, rgba(255,70,70,0.2), rgba(255,180,40,0.12));
    border: 0.5px solid rgba(255,150,100,0.7);
    border-radius: 40px;
    padding: 5px 8px;
    font-size: 8.5px;
    font-weight: 700;
    color: #FFCCAA;
    cursor: pointer;
    backdrop-filter: blur(8px);
    transition: all 0.12s;
    text-align: center;
}
.close-button:active {
    transform: scale(0.96);
    background: rgba(255,80,80,0.3);
}
.svg-defs {
    position: absolute;
    width: 0;
    height: 0;
}
</style>
</head>
<body>
<div class="svg-defs">
    <svg width="0" height="0">
        <defs>
            <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#FFD966" />
                <stop offset="100%" stop-color="#FF8C42" />
            </linearGradient>
        </defs>
    </svg>
</div>
<div class="card" id="premiumCard">
    <div class="header">
        <div id="iconTitle" class="title-icon"></div>
        <div class="title">RIYAZ ACCESS</div>
    </div>
    <div class="expire-status">
        <div class="expire-text">🔴 RIYAZ ACCESS REVOKED</div>
    </div>
    <div class="device-info"><div id="deviceInfo"></div></div>
    <div class="content">
        <div class="row"><div id="iconSupport" class="icon"></div><div class="text"><span class="highlight">▸ Support:</span> Android 8–17</div></div>
        <div class="row"><div id="iconDev" class="icon"></div><div class="text"><span class="highlight">▸ Developer:</span> RIYAZ BBOX</div></div>
        <div class="row"><div id="iconContact" class="icon"></div><div class="text"><span class="highlight">▸ Contact:</span> Officials</div></div>
    </div>
    <div class="android-support"><div class="support-text">✦ SECURED BY RIYAZ SDK ✦</div></div>
    <div class="footer">
        <div class="footer-row"><div id="iconPerfect" class="footer-icon"></div><span class="footer-text">RIYAZ DIAMOND</span></div>
        <div class="footer-note">License expired • Renew now</div>
        <div class="countdown-card">
            <span class="timer-label">AUTO LOCK</span>
            <span class="timer-digits" id="timerDigits">10</span>
            <div class="ring-container">
                <svg class="circular-ring" viewBox="0 0 32 32">
                    <circle class="bg-ring" cx="16" cy="16" r="13.5"></circle>
                    <circle id="progressRing" class="progress-ring" cx="16" cy="16" r="13.5" stroke-dasharray="84.823" stroke-dashoffset="0"></circle>
                </svg>
            </div>
        </div>
        <div class="close-button" id="dismissBtn">✕ CLOSE SESSION</div>
    </div>
</div>
<script>
(function() {
    // Lottie icons
    const icons = [
        { id: 'iconTitle', path: 'https://assets10.lottiefiles.com/packages/lf20_j1adxtyb.json' },
        { id: 'iconSupport', path: 'https://assets2.lottiefiles.com/packages/lf20_jcikwtux.json' },
        { id: 'iconDev', path: 'https://assets7.lottiefiles.com/packages/lf20_w51pcehl.json' },
        { id: 'iconContact', path: 'https://assets3.lottiefiles.com/packages/lf20_5ngs2ksb.json' },
        { id: 'iconPerfect', path: 'https://assets4.lottiefiles.com/packages/lf20_jtbfg2nb.json' }
    ];
    icons.forEach(ic => {
        const el = document.getElementById(ic.id);
        if (el) {
            try {
                lottie.loadAnimation({ container: el, renderer: 'svg', loop: true, autoplay: true, path: ic.path });
            } catch(e) {}
        }
    });

    // Device info
    function loadDeviceInfo() {
        if (window.Android && typeof Android.getDeviceInfo === 'function') {
            try {
                const raw = Android.getDeviceInfo();
                const lines = raw.split('\n');
                const container = document.getElementById('deviceInfo');
                if (container) {
                    container.innerHTML = '';
                    lines.forEach(line => {
                        if (line.trim()) {
                            let [label, value] = line.split(':').map(s => s.trim());
                            if (label && value) {
                                const row = document.createElement('div');
                                row.className = 'info-row';
                                row.innerHTML = '<span class="info-label">' + label + ':</span><span class="info-value">' + value + '</span>';
                                container.appendChild(row);
                            }
                        }
                    });
                    if (container.children.length === 0) container.innerHTML = '<div class="info-row"><span class="info-label">Device</span><span class="info-value">RIYAZ</span></div>';
                }
            } catch(e) {}
        }
    }

    // Floating particles for premium feel
    function addParticles() {
        const card = document.getElementById('premiumCard');
        if (!card) return;
        for (let i = 0; i < 12; i++) {
            const p = document.createElement('div');
            p.className = 'particle';
            const sz = Math.random() * 4 + 2;
            p.style.width = sz + 'px';
            p.style.height = sz + 'px';
            p.style.left = (Math.random() * 100) + '%';
            p.style.top = (Math.random() * 100) + '%';
            p.style.animationDelay = (Math.random() * 5) + 's';
            p.style.animationDuration = (Math.random() * 4 + 3) + 's';
            card.appendChild(p);
        }
    }

    loadDeviceInfo();
    addParticles();

    // Countdown
    let seconds = 10;
    const timerSpan = document.getElementById('timerDigits');
    const ring = document.getElementById('progressRing');
    const circum = 2 * Math.PI * 13.5; // ~84.823
    let interval = null;

    function updateRing(sec) {
        if (ring) {
            const offset = circum * (1 - (sec / 10));
            ring.style.strokeDasharray = circum + ' ' + circum;
            ring.style.strokeDashoffset = offset;
        }
        if (timerSpan) timerSpan.innerText = sec;
    }

    function startTimer() {
        updateRing(seconds);
        interval = setInterval(() => {
            seconds--;
            if (seconds >= 0) {
                updateRing(seconds);
                if (seconds === 3) {
                    const card = document.querySelector('.card');
                    if (card) card.style.transform = 'scale(1.02)';
                    setTimeout(() => { if(card) card.style.transform = ''; }, 180);
                }
                if (seconds <= 0) {
                    clearInterval(interval);
                    if (window.Android && typeof Android.close === 'function') Android.close();
                }
            } else {
                clearInterval(interval);
            }
        }, 1000);
    }
    startTimer();

    // Manual close
    const closeBtn = document.getElementById('dismissBtn');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            if (interval) clearInterval(interval);
            if (window.Android && typeof Android.close === 'function') Android.close();
        });
    }

    // Fallback close
    setTimeout(() => {
        if (seconds > 0 && window.Android && typeof Android.close === 'function') Android.close();
    }, 10500);
})();
</script>
</body>
</html>
"""
}