package android.app;

/**
 * Compile-time stub for the hidden Android 16 type android.app.IBinderSession.
 * At runtime on API 36 the framework's real class is used (parent-first
 * class loading), so this only exists to make the method signature compile.
 */
public interface IBinderSession {
}
