package black.android.app;

import android.content.ComponentName;
import android.os.IBinder;

import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BMethod;
import top.niunaijun.blackreflection.annotation.BParamClassName;

// Android 16 (API 36): connected(ComponentName, IBinder, IBinderSession, boolean)
@BClassName("android.app.IServiceConnection")
public interface IServiceConnectionBaklava {
    @BMethod
    void connected(ComponentName name, IBinder service,
                   @BParamClassName("android.app.IBinderSession") Object session,
                   boolean dead);
}
