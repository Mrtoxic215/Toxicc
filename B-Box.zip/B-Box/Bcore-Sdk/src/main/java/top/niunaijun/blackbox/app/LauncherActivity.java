package top.niunaijun.blackbox.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.R;
import top.niunaijun.blackbox.utils.Slog;
import top.niunaijun.blackbox.core.BcoreDebug;

import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class LauncherActivity extends Activity {

    public static final String TAG = "LauncherActivity";
    public static final String KEY_INTENT = "launch_intent";
    public static final String KEY_PKG = "launch_pkg";
    public static final String KEY_USER_ID = "launch_user_id";

    private boolean isRunning = false;
    private Handler handler = new Handler(Looper.getMainLooper());

    public static void launch(Intent intent, int userId) {
        Intent splash = new Intent();
        splash.setClass(BlackBoxCore.getContext(), LauncherActivity.class);
        splash.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        splash.putExtra(KEY_INTENT, intent);
        splash.putExtra(KEY_PKG, intent.getPackage());
        splash.putExtra(KEY_USER_ID, userId);
        BlackBoxCore.getContext().startActivity(splash);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BcoreDebug.mark("LauncherActivity.onCreate");

        Intent intent = getIntent();
        if (intent == null) {
            finish();
            return;
        }

        Intent launchIntent = intent.getParcelableExtra(KEY_INTENT);
        String packageName = intent.getStringExtra(KEY_PKG);
        int userId = intent.getIntExtra(KEY_USER_ID, 0);

        if (launchIntent == null) {
            Slog.e(TAG, "launchIntent is null! Cannot launch app.");
            finish();
            return;
        }

        if (packageName == null) {
            packageName = launchIntent.getPackage();

            if (packageName == null) {
                Slog.e(TAG, "Package name is null! Cannot launch app.");
                finish();
                return;
            }
        }

        BcoreDebug.log(
                "Launcher parsed package="
                        + packageName
                        + " user="
                        + userId
                        + " intent="
                        + launchIntent
        );

        PackageInfo packageInfo =
                BlackBoxCore.getBPackageManager()
                        .getPackageInfo(packageName, 0, userId);

        if (packageInfo == null) {
            Slog.e(TAG, packageName + " not installed!");
            finish();
            return;
        }

        setContentView(R.layout.activity_launcher_premium);

        // ===== App Icon =====
        Drawable icon = packageInfo.applicationInfo.loadIcon(
                BlackBoxCore.getPackageManager()
        );

        ImageView iconView = findViewById(R.id.iv_icon);
        iconView.setImageDrawable(icon);

        // ===== App Name =====
        TextView nameView = findViewById(R.id.tv_app_name);

        CharSequence label = packageInfo.applicationInfo.loadLabel(
                BlackBoxCore.getPackageManager()
        );

        nameView.setText(label);

        // ===== Premium Loading Text =====
        TextView loadingText = findViewById(R.id.tv_loading_text);

        // ===== Custom ProgressBar =====
        ProgressBar progressBar = findViewById(R.id.progress_bar);

        // ===== Animations =====

        // Icon: scale + alpha
        iconView.setScaleX(0.6f);
        iconView.setScaleY(0.6f);
        iconView.setAlpha(0f);

        iconView.animate()
                .scaleX(1f)
                .scaleY(1f)
                .alpha(1f)
                .setDuration(500)
                .setInterpolator(new OvershootInterpolator())
                .start();

        // Name: fade and slide up
        nameView.setTranslationY(40f);
        nameView.setAlpha(0f);

        nameView.animate()
                .translationY(0f)
                .alpha(1f)
                .setDuration(400)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .start();

        // Loading text
        animateLoadingText(loadingText);

        // Progress bar
        progressBar.animate()
                .alpha(1f)
                .setDuration(300)
                .start();

        /*
         * IMPORTANT:
         * packageName was reassigned above, so it is not effectively final.
         * Create final copies before using them inside lambdas/threads.
         */
        final String finalPackageName = packageName;
        final Intent finalLaunchIntent = launchIntent;
        final int finalUserId = userId;

        // ===== Launch app after short delay =====
        handler.postDelayed(() -> {

            BcoreDebug.mark(
                    "LauncherActivity: calling BActivityManager.startActivity"
            );

            new Thread(() -> {
                try {

                    BcoreDebug.log(
                            "BActivityManager.startActivity BEGIN package="
                                    + finalPackageName
                                    + " component="
                                    + finalLaunchIntent.getComponent()
                    );

                    BlackBoxCore.getBActivityManager()
                            .startActivity(
                                    finalLaunchIntent,
                                    finalUserId
                            );

                    BcoreDebug.log(
                            "BActivityManager.startActivity RETURNED"
                    );

                } catch (Throwable t) {

                    BcoreDebug.log(
                            "BActivityManager.startActivity THROW",
                            t
                    );

                    throw new RuntimeException(t);
                }
            }).start();

        }, 800);
    }

    private void animateLoadingText(TextView textView) {

        final String[] dots = {"", ".", "..", "..."};
        final int[] index = {0};

        handler.post(new Runnable() {

            @Override
            public void run() {

                if (!isFinishing() && !isDestroyed()) {

                    textView.setText(
                            "launching" + dots[index[0]]
                    );

                    index[0] =
                            (index[0] + 1) % dots.length;

                    handler.postDelayed(this, 500);
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        isRunning = true;
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (isRunning) {
            finish();
        }
    }
}