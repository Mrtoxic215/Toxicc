package top.niunaijun.blackbox.core.system.device;

import top.niunaijun.blackbox.entity.device.BDeviceInfo;

/**
 * Device Manager Service Interface
 */
interface IBDeviceManagerService {

    void setPattern(int userId, String pkg, int pattern);
    int getPattern(int userId, String pkg);

    void setDeviceInfo(int userId, String pkg, in BDeviceInfo info);
    BDeviceInfo getDeviceInfo(int userId, String pkg);

    void setGlobalDeviceInfo(in BDeviceInfo info);
    BDeviceInfo getGlobalDeviceInfo();

    void setImei(int userId, String pkg, String imei);
    String getImei(int userId, String pkg);

    void setAndroidId(int userId, String pkg, String androidId);
    String getAndroidId(int userId, String pkg);

    void setModel(int userId, String pkg, String model);
    String getModel(int userId, String pkg);

    void setManufacturer(int userId, String pkg, String manufacturer);
    String getManufacturer(int userId, String pkg);

    void setBrand(int userId, String pkg, String brand);
    String getBrand(int userId, String pkg);

    void resetToReal(int userId, String pkg);
}