package top.niunaijun.blackbox.entity.device;

parcelable BDeviceInfo;